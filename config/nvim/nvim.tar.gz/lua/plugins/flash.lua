return {
  "folke/flash.nvim",
}
